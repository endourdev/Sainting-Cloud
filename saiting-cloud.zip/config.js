module.exports = {
    intents: 3276799
}